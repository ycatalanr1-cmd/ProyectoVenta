﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aplicacion.DTO
{
    public record UpdatePedidoInternoDTO(
        int id,
        string? codigo,
        int? cantidad,
        int id_Departamento,
        int? id_OrdenCompra,
        DateTime Fecha_Solicitada,
        DateTime Fecha_Ingreso,
        bool urgente,
        string? Observaciones,                    
        List<CreateDetallePedidoDTO>? Articulos
    );



}